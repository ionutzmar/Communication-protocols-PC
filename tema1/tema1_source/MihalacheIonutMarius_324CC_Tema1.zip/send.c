#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "link_emulator/lib.h"

#define HOST "127.0.0.1"
#define PORT 10000
#define MAXFILESIZE 4000

typedef struct {
    int ack;
    int size;
    char payload[1388];
    int parity;
} my_pkt;

int main(int argc,char** argv){
    init(HOST,PORT);
    msg t, r;
    int lastIndex = 0; //va retine numarul total de pachete care vor fi trimise
    my_pkt *file = (my_pkt *) calloc(MAXFILESIZE, sizeof(my_pkt));

    if (file == NULL) {
        perror("Could not allocate buffer");
        exit(1);
    }
    int fileFd;
    if ((fileFd = open(argv[1], O_RDONLY)) < 0) {
        perror("Could not open file for reading.");
        exit(1);
    }

    strcpy(file[lastIndex].payload, argv[1]);
    file[lastIndex].ack = 0;
    lastIndex++; //primul pachet cu numele fisierului
    lastIndex++; //pentru al doilea pachet, in care trimitem numarul total de pachete
    ssize_t bytesRead;
    while ((bytesRead = read(fileFd, file[lastIndex].payload, sizeof(file[lastIndex].payload))) > 0) {
        file[lastIndex].ack = lastIndex;
        file[lastIndex].size = bytesRead;
        lastIndex++;
    }

    sprintf(file[1].payload, "%d", lastIndex);
    file[1].ack = 1;

    int i, k;

    for (k = 0; k < lastIndex; k++) {
        int sum = 0;
        for (i = 0; i < sizeof(file[k].payload); i++) {
            sum += file[k].payload[i];
        }
        sum += file[k].ack;
        sum += file[k].size;
        file[k].parity = sum;
    }


    int windowSize = atoi(argv[2]) * atoi(argv[3]) * 1000 / (sizeof(msg) * 8);

    int receivedAcks = 0;
    int messagesOnWire = 0;
    t.len = 1400;
    i = 0;
    char begun = 0;
    while(receivedAcks < lastIndex) {
        if (messagesOnWire >= windowSize) {
            //receive ack
            if (recv_message_timeout(&r, 10) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
                continue;
            }
        }

        if (lastIndex - receivedAcks <= windowSize) {
            if (recv_message_timeout(&r, 10) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
            }
        }
        int sw = 0;
        //Daca recv_message_timeout nu primeste niciun mesaj timp de (delay / 10)
        //milisecunde atunci inseamna ca toate mesajele pe care le consider trimise sunt
        //de fapt pierdute. Fac messagesOnWire = 0; Am delay / 10 pentru ca maxim
        //10% dintre pachete se pierd.
        if ((begun != 0) && (recv_message_timeout(&r, atoi(argv[3]) / 10) >= 0)) {
            my_pkt m = *(my_pkt *)r.payload;
            int index = m.ack;
            file[index].ack = -1;
            receivedAcks++;
            messagesOnWire++;
        } else if(begun != 0) {
            messagesOnWire = 0;
        }
        while (messagesOnWire < windowSize) {
            if (recv_message_timeout(&r, 1) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
            }
            if (i == lastIndex)
                i = 0;
            int currentIndex = i;
            while (file[currentIndex].ack == -1) {
                if (currentIndex >= (lastIndex - 1))
                    currentIndex = 0;
                else
                    currentIndex++;
                if (currentIndex == i) {
                    sw = 1;
                    break;
                }
            }
            if (sw) break;
            i = currentIndex;

            memcpy(t.payload, &file[i], sizeof(file[i]));
            send_message(&t);
            begun = 1;
            messagesOnWire++;
            i++;
        }
    }

    close(fileFd);
    free(file);
    // sleep(0.2);
    return 0;
}
