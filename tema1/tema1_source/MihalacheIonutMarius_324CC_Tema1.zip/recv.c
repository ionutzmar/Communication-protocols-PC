#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "link_emulator/lib.h"

#define HOST "127.0.0.1"
#define PORT 10001
#define MAXFILESIZE 4000

typedef struct {
    int ack;
    int size;
    char payload[1388];
    int parity;
} my_pkt;

int main(int argc,char** argv){
    msg r;
    init(HOST,PORT);
    my_pkt file[MAXFILESIZE];
    int accept = 1;
    int i;
    int receivedPackets = 0;
     file[0].ack = -1;
    while (accept) {
        if (recv_message(&r) < 0){
            perror("Receive message");
            return -1;
        }
        my_pkt m = *(my_pkt *)r.payload;
        int sum = 0;
        for (i = 0; i < sizeof(m.payload); i++) {
            sum += m.payload[i];
        }
        sum += m.ack;
        sum += m.size;

        if (m.parity == sum) {
            if (m.ack < 0)
                continue;
            if (m.ack == file[m.ack].ack) //in caz de se pierd ack-urile trimise
                continue;
            file[m.ack] = m;
            send_message(&r);
            receivedPackets++;
        }

        if (file[1].ack == 1) {
            accept = atoi(file[1].payload) - receivedPackets;
        }
    }
    char finalName[25];
    char inputFileName[20];
    strcpy(inputFileName, file[0].payload);
    sprintf(finalName, "recv_%s", inputFileName);

    int fileFd;
    if ((fileFd = open(finalName, O_WRONLY | O_CREAT, 0666)) < 0) {
        perror("Cannot create output file");
        exit(1);
    }

    for (i = 2; i < receivedPackets; i++) {
        if (write(fileFd, file[i].payload, file[i].size) < 0) {
            perror("Could not write to the output file");
            exit(1);
        }
    }
    close(fileFd);
    return 0;
}
