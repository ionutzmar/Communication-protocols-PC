#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "link_emulator/lib.h"
#include <sys/time.h>

#define HOST "127.0.0.1"
#define PORT 10000
#define MAXFILESIZE 4000

typedef struct {
    int ack;
    int size;
    char payload[1388];
    int parity;
} my_pkt;

int main(int argc,char** argv){
    init(HOST,PORT);
    msg t, r;
    int lastIndex = 0;
    my_pkt *file = (my_pkt *) calloc(MAXFILESIZE, sizeof(my_pkt));
    struct timeval lastPacketTime, now;
    gettimeofday(&lastPacketTime, NULL);
    if (file == NULL) {
        perror("Could not allocate buffer");
        exit(1);
    }
    int fileFd;
    if ((fileFd = open(argv[1], O_RDONLY)) < 0) {
        perror("Could not open file for reading.");
        exit(1);
    }

    strcpy(file[lastIndex].payload, argv[1]);
    file[lastIndex].ack = 0;
    lastIndex++; //primul pachet cu numele fisierului
    lastIndex++; //pentru al doilea pachet, in care trimitem numarul total de pachete
    ssize_t bytesRead;
    while ((bytesRead = read(fileFd, file[lastIndex].payload, sizeof(file[lastIndex].payload))) > 0) {
        file[lastIndex].ack = lastIndex;
        file[lastIndex].size = bytesRead;
        lastIndex++;
    }

    sprintf(file[1].payload, "%d", lastIndex);
    file[1].ack = 1;

    int i, k;

    for (k = 0; k < lastIndex; k++) {
        int sum = 0;
        for (i = 0; i < sizeof(file[k].payload); i++) {
            sum += file[k].payload[i];
        }
        sum += file[k].ack;
        sum += file[k].size;
        file[k].parity = sum;
    }


    int windowSize = atoi(argv[2]) * atoi(argv[3]) * 1000 / (sizeof(msg) * 8);

    int receivedAcks = 0;
    int messagesOnWire = 0;
    t.len = 1400;
    i = 0;
    while(receivedAcks < lastIndex) {
        if (messagesOnWire >= windowSize) {
            //receive ack
            if (recv_message_timeout(&r, 10) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
                continue;
            }
        }

        if (lastIndex - receivedAcks <= windowSize) {
            if (recv_message_timeout(&r, 10) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
            }
        }
        int sw = 0;
        gettimeofday(&now, NULL);
        if ((now.tv_usec - lastPacketTime.tv_usec + (now.tv_sec - lastPacketTime.tv_sec) * 1000000) / 1000 > atoi(argv[3]) * 0.2) {
            messagesOnWire = 0; //toate pachetele au fost pierdute
        }
        while (messagesOnWire < windowSize) {
            if (recv_message_timeout(&r, 1) >= 0) {
                my_pkt m = *(my_pkt *)r.payload;
                int index = m.ack;
                file[index].ack = -1;
                receivedAcks++;
                messagesOnWire--;
            }
            if (i == lastIndex)
                i = 0;
            int currentIndex = i;
            while (file[currentIndex].ack == -1) {
                if (currentIndex >= (lastIndex - 1))
                    currentIndex = 0;
                else
                    currentIndex++;
                if (currentIndex == i) {
                    sw = 1;
                    break;
                }
            }
            if (sw) break;
            i =  currentIndex;

            fprintf(stderr, "I-ul este: %d\n", i);
            fprintf(stderr, "[sender]I have send no %d\n", file[i].ack);
            memcpy(t.payload, &file[i], sizeof(file[i]));
            send_message(&t);
            gettimeofday(&lastPacketTime, NULL);
            messagesOnWire++;
            i++;
        }
    }

    close(fileFd);
    free(file);
    sleep(0.2);
    return 0;
}
