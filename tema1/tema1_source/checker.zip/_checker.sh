#!/bin/bash
./run_experiment.sh
